
import React from 'react'
import Base from "../core/Base"
const UserDashBoard=()=> {
    return (
      <Base title="UserDashBoard page">
      This is UserDashBoard PAge
      </Base>
    )
}

export default UserDashBoard
