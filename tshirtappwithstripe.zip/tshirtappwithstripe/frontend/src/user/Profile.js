import React from 'react'
import Base from "../core/Base"
const Profile=()=> {
    return (
      <Base title="Profile page">
      This is profile PAge
      </Base>
    )
}

export default Profile
